

class TourArcher():
    def __init__(self, x, y, speed = 50, attaque = 1):
        #self.imgTourArcher = tPhotoImage(file = "icones/tour_archer.png")
        self.x = x
        self.y = y
        self.speed = speed
        self.attaque = attaque