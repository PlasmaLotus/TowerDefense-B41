class Path(object):
	"""docstring for Path"""
	def __init__(self, arg):
		super(Path, self).__init__()
		self.arg = arg
		