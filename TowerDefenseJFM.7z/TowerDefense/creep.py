

class Creep():
	def __init(self, x = 0, y = 0, hp = 100, speed = 50):
		self.x = x
		self.y = y
		self.hp = hp
		self.speed = speed

	